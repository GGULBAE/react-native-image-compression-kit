require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name = "react-native-image-compression-kit"
  s.version = package["version"]
  s.summary = package["description"]
  s.license = package["license"]
  s.homepage = "https://github.com/GGULBAE/react-native-image-compression-kit"
  s.authors = "react-native-image-compression-kit contributors"
  s.source = { :git => "https://github.com/GGULBAE/react-native-image-compression-kit.git", :tag => "v#{s.version}" }
  s.platforms = { :ios => "13.4" }
  s.source_files = "ios/**/*.{h,m,mm}"
  s.private_header_files = [
    "ios/RCTImageCompressionImageDecoder.h",
    "ios/RCTImageCompressionImageEncoder.h",
    "ios/RCTImageCompressionImageTransformer.h",
    "ios/RCTImageCompressionInput.h",
    "ios/RCTImageCompressionIOSCapabilities.h",
    "ios/RCTImageCompressionJpegMetadata.h",
    "ios/RCTImageCompressionOutput.h",
    "ios/RCTImageCompressionPipeline.h",
    "ios/RCTImageCompressionRequest.h",
  ]

  if respond_to?(:install_modules_dependencies, true)
    install_modules_dependencies(s)
  else
    s.dependency "React-Core"
  end
end
