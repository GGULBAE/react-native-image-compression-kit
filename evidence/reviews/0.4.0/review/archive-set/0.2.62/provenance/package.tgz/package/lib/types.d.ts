export declare const IMAGE_FORMATS: readonly ["jpeg", "png", "webp", "heic", "heif", "avif", "gif"];
export declare const OUTPUT_FORMATS: readonly ["jpeg", "png", "webp", "heic", "heif", "avif"];
export declare const METADATA_POLICIES: readonly ["preserve", "safe", "strip"];
export declare const RESIZE_MODES: readonly ["contain", "cover", "stretch"];
export type ImageFormat = (typeof IMAGE_FORMATS)[number];
export type OutputFormat = (typeof OUTPUT_FORMATS)[number];
export type MetadataPolicy = (typeof METADATA_POLICIES)[number];
export type ResizeMode = (typeof RESIZE_MODES)[number];
export interface CompressionSource {
    uri: string;
}
export interface ResizeOptions {
    maxWidth?: number;
    maxHeight?: number;
    mode?: ResizeMode;
}
export interface OutputOptions {
    format: OutputFormat;
    quality?: number;
    maxBytes?: number;
}
export interface CompressionOptions {
    source: CompressionSource;
    resize?: ResizeOptions;
    output: OutputOptions;
    metadata?: MetadataPolicy;
}
export interface NormalizedResizeOptions extends Omit<ResizeOptions, 'mode'> {
    mode: ResizeMode;
}
export interface NormalizedCompressionOptions extends Omit<CompressionOptions, 'metadata' | 'resize'> {
    metadata: MetadataPolicy;
    resize?: NormalizedResizeOptions;
}
export interface CompressionResult {
    uri: string;
    format: OutputFormat;
    width: number;
    height: number;
    byteSize: number;
    originalByteSize: number;
    compressionRatio: number;
}
export interface FormatCapability {
    format: ImageFormat;
    input: boolean;
    output: boolean;
    supportsAlpha: boolean;
    supportsAnimation: boolean;
    notes?: string[];
}
export interface ImageCompressionCapabilities {
    platform: 'android' | 'ios' | 'unknown';
    formats: FormatCapability[];
    metadataPolicies: MetadataPolicy[];
    supportsTargetSizeCompression: boolean;
    supportsCancellation: boolean;
}
//# sourceMappingURL=types.d.ts.map