import type { Spec as NativeImageCompressionKitSpec } from './NativeImageCompressionKit';
export declare const NATIVE_MODULE_NAME = "ImageCompressionKit";
export type NativeImageCompressionKitModule = NativeImageCompressionKitSpec;
export declare function getNativeModule(): NativeImageCompressionKitModule;
export declare function setNativeModuleForTesting(nativeModule: NativeImageCompressionKitModule | null): void;
export declare function resetNativeModuleForTesting(): void;
//# sourceMappingURL=nativeModule.d.ts.map