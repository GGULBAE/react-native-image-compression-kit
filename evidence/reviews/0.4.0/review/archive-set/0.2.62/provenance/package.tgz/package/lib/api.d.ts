import type { CompressionOptions, CompressionResult, ImageCompressionCapabilities } from './types';
export declare function compressImage(options: CompressionOptions): Promise<CompressionResult>;
export declare function getImageCompressionCapabilities(): Promise<ImageCompressionCapabilities>;
//# sourceMappingURL=api.d.ts.map