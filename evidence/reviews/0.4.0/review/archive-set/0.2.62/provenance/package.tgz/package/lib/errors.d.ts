export type ImageCompressionKitErrorCode = 'ERR_INVALID_OPTIONS' | 'ERR_UNSUPPORTED_SOURCE' | 'ERR_UNSUPPORTED_FORMAT' | 'ERR_NATIVE_MODULE_UNAVAILABLE' | 'ERR_NOT_IMPLEMENTED' | 'ERR_FILE_ACCESS' | 'ERR_DECODE_FAILED' | 'ERR_ENCODE_FAILED' | 'ERR_NATIVE_OPERATION_FAILED';
export declare class ImageCompressionKitError extends Error {
    readonly code: ImageCompressionKitErrorCode;
    constructor(code: ImageCompressionKitErrorCode, message: string, options?: {
        cause?: unknown;
    });
}
export declare function normalizeNativeError(error: unknown): Error;
//# sourceMappingURL=errors.d.ts.map