import { type CompressionOptions, type NormalizedCompressionOptions } from './types';
export declare function normalizeCompressionOptions(options: CompressionOptions): NormalizedCompressionOptions;
//# sourceMappingURL=validation.d.ts.map