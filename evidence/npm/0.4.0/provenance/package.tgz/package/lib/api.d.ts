import type { CompressionOptions, CompressionAbortSignal, CompressionControl, CompressionResult, ImageCompressionCapabilities } from './types';
export declare function compressImage(options: CompressionOptions, control?: CompressionControl | CompressionAbortSignal): Promise<CompressionResult>;
export declare function getImageCompressionCapabilities(): Promise<ImageCompressionCapabilities>;
//# sourceMappingURL=api.d.ts.map